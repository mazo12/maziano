import os
import sys
import subprocess
import json
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

def install_requirements():
    try:
        import telegram
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "python-telegram-bot==20.3"])
install_requirements()

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    level=logging.INFO)

TOKEN = "YOUR_BOT_TOKEN"
CHANNEL_USERNAME = "@joskar"
OWNER_ID = 6534780281
DATA_FILE = "data.json"

def load_data():
    if not os.path.exists(DATA_FILE):
        return {"replies": {}, "admins": [OWNER_ID]}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

data = load_data()

def is_admin(user_id: int) -> bool:
    return user_id in data.get("admins", [])

def add_admin(user_id: int):
    if user_id not in data["admins"]:
        data["admins"].append(user_id)
        save_data(data)

def remove_admin(user_id: int):
    if user_id in data["admins"] and user_id != OWNER_ID:
        data["admins"].remove(user_id)
        save_data(data)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    member = await context.bot.get_chat_member(CHANNEL_USERNAME, user.id)
    if member.status in ["left", "kicked"]:
        await update.message.reply_text(f"⚠️ لازم تشترك في القناة أولاً: {CHANNEL_USERNAME}")
    else:
        if is_admin(user.id):
            await update.message.reply_text("✅ أهلاً بيك يا أدمن. استخدم الأوامر لإدارة البوت.")
        else:
            await update.message.reply_text("✅ أهلاً بيك! دلوقتي تقدر تستخدم البوت.")

async def add_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) < 2:
        await update.message.reply_text("❌ الاستخدام: /addreply الكلمة الرد")
        return
    key = context.args[0].lower()
    reply = " ".join(context.args[1:])
    data["replies"][key] = reply
    save_data(data)
    await update.message.reply_text(f"✅ تمت إضافة الرد:\n{key} → {reply}")

async def del_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) < 1:
        await update.message.reply_text("❌ الاستخدام: /delreply الكلمة")
        return
    key = context.args[0].lower()
    if key in data["replies"]:
        del data["replies"][key]
        save_data(data)
        await update.message.reply_text(f"🗑️ تم حذف الرد على: {key}")
    else:
        await update.message.reply_text("⚠️ الكلمة غير موجودة.")

async def list_replies(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not data["replies"]:
        await update.message.reply_text("📭 لا توجد ردود حالياً.")
        return
    msg = "📋 الردود الحالية:\n"
    for k, v in data["replies"].items():
        msg += f"- {k} → {v}\n"
    await update.message.reply_text(msg)

async def add_admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    if len(context.args) != 1:
        await update.message.reply_text("❌ الاستخدام: /addadmin user_id")
        return
    try:
        new_admin = int(context.args[0])
        add_admin(new_admin)
        await update.message.reply_text(f"✅ تم إضافة {new_admin} كأدمن.")
    except ValueError:
        await update.message.reply_text("⚠️ لازم تكتب ID صحيح.")

async def del_admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        return
    if len(context.args) != 1:
        await update.message.reply_text("❌ الاستخدام: /deladmin user_id")
        return
    try:
        admin_id = int(context.args[0])
        if admin_id == OWNER_ID:
            await update.message.reply_text("⚠️ لا يمكن حذف المالك الأساسي.")
            return
        remove_admin(admin_id)
        await update.message.reply_text(f"🗑️ تم إزالة {admin_id} من الأدمنز.")
    except ValueError:
        await update.message.reply_text("⚠️ لازم تكتب ID صحيح.")

async def list_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    msg = "👮‍♂️ الأدمنز الحاليين:\n"
    for adm in data["admins"]:
        msg += f"- {adm}\n"
    await update.message.reply_text(msg)

async def auto_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    member = await context.bot.get_chat_member(CHANNEL_USERNAME, user.id)
    if member.status in ["left", "kicked"]:
        await update.message.reply_text(f"⚠️ لازم تشترك هنا: {CHANNEL_USERNAME}")
        return
    text = update.message.text.lower()
    for key, reply in data["replies"].items():
        if key in text:
            await update.message.reply_text(reply)
            return

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("addreply", add_reply))
    app.add_handler(CommandHandler("delreply", del_reply))
    app.add_handler(CommandHandler("listreplies", list_replies))
    app.add_handler(CommandHandler("addadmin", add_admin_cmd))
    app.add_handler(CommandHandler("deladmin", del_admin_cmd))
    app.add_handler(CommandHandler("listadmins", list_admins))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, auto_reply))
    app.run_polling()

if __name__ == "__main__":
    main()
